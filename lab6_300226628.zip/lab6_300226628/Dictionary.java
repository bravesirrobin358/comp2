public class Dictionary implements Map<String, Integer> {

    private final static int INITIAL_CAPACITY = 10;
    private final static int INCREMENT = 5;
    private int count;

    private Pair[] elems;

    public int getCount() {
      return count;
    }

    public int getCapacity() {
      return elems.length;
    }

    public Dictionary() {
        count = 0;
        elems = new Pair[INITIAL_CAPACITY];
    }

    @Override
    public void put(String key, Integer value) {
        if (getCount() == getCapacity()){
            increaseCapacity();
        }
        elems[getCount()] = new Pair(key, value);
        count++;
        return;
    }

    private void increaseCapacity() {
        Pair[] temp = new Pair[getCapacity() + INCREMENT];
            for (int i=0; i<elems.length; i++){
                temp[i] = elems[i];
            }
            elems = new Pair[temp.length];
            for (int i=0; i<temp.length; i++){
                elems[i] = temp[i];
            }
    }

    @Override
    public boolean contains(String key) {
        for (int i=0; i<getCapacity(); i++){
            if (elems[i] != null){
                if (elems[i].getKey().equals(key)){
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public Integer get(String key) {
        for (int i=getCount()-1; i>-1; i--){
            if (elems[i] != null){
                if (elems[i].getKey().equals(key)){
                    return elems[i].getValue();
                }
            }
        }
        return 0;
    }

    @Override
    public void replace(String key, Integer value) {
        for (int i=getCount()-1; i>-1; i--){
            if (elems[i].getKey().equals(key)){
                elems[i].setValue(value);
                return;
            }
        }
    }

    @Override
    public Integer remove(String key) {
        int value;
        for (int i=getCount()-1; i>-1; i--){
            if (elems[i].getKey().equals(key)){
                value = elems[i].getValue();
                elems[i] = null;
                count--;
                return value;
            }
        }
        return 0;
    }

    @Override
    public String toString() {
      String res;
      res = "Dictionary: {elems = [";
      for (int i = count-1; i >= 0 ; i--) {
          res += elems[i];
          if(i > 0) {
              res += ", ";
          }
      }
      return res +"]}";
    }

}