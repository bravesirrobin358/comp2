Student name: Yannick Vaillancourt
Student number: 300226628
Course code: ITI1121
Lab section: B-3

This archive contains the 11 files of lab 7, that is, this file (README.txt),
plus Exercise1.java, Account.java, NotEnoughMoneyException.java, Stack.java, ArrayStack.java, DynamicArrayStack.java, FullStackException.java, Map.java, Dictionary.java, Pair.java.